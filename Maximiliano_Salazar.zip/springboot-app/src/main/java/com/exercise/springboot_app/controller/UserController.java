package com.exercise.springboot_app.controller;

import com.exercise.springboot_app.model.User;
import com.exercise.springboot_app.model.Address;
import com.exercise.springboot_app.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/users")
public class UserController {

    @Autowired
    private UserService userService;

    // GET /users?sortedBy=email
    @GetMapping
    public ResponseEntity<List<User>> getUsers(@RequestParam(value = "sortedBy", required = false) String sortedBy) {
        List<User> users = userService.getUsersSortedBy(sortedBy);
        return new ResponseEntity<>(users, HttpStatus.OK);
    }

    // GET /users/{user_id}/addresses
    @GetMapping("/{user_id}/addresses")
    public ResponseEntity<List<Address>> getUserAddresses(@PathVariable("user_id") int userId) {
        List<Address> addresses = userService.getUserAddresses(userId);
        if (addresses != null) {
            return new ResponseEntity<>(addresses, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // PUT /users/{user_id}/addresses/{address_id}
    @PutMapping("/{user_id}/addresses/{address_id}")
    public ResponseEntity<Address> updateUserAddress(
            @PathVariable("user_id") int userId,
            @PathVariable("address_id") int addressId,
            @RequestBody Address newAddress) {

        Address updatedAddress = userService.updateUserAddress(userId, addressId, newAddress);
        if (updatedAddress != null) {
            return new ResponseEntity<>(updatedAddress, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // POST /users
    @PostMapping
    public ResponseEntity<User> saveUser(@RequestBody User user) {
        User savedUser = userService.saveUser(user);
        return new ResponseEntity<>(savedUser, HttpStatus.CREATED);
    }

    // PATCH /users/{id}
    @PatchMapping("/{id}")
    public ResponseEntity<User> patchUser(
            @PathVariable("id") int id,
            @RequestBody Map<String, Object> updates) {

        User updatedUser = userService.updateUserAttribute(id, updates);
        if (updatedUser != null) {
            return new ResponseEntity<>(updatedUser, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // DELETE /users/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable("id") int id) {
        String result = userService.deleteUserById(id);
        if (result != null) {
            return new ResponseEntity<>(result, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // GET /users/{id}
    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable("id") int id) {
        User user = userService.getUserById(id);
        if (user != null) {
            return new ResponseEntity<>(user, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}