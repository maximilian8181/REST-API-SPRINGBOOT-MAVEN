package com.exercise.springboot_app.service;

import com.exercise.springboot_app.model.Address;
import com.exercise.springboot_app.model.User;
import com.exercise.springboot_app.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public List<User> getUsersSortedBy(String attribute) {
        return userRepository.findAllSortedBy(attribute);
    }

    public List<Address> getUserAddresses(int userId) {
        return userRepository.findAddressesByUserId(userId);
    }

    public Address updateUserAddress(int userId, int addressId, Address newAddress) {
        return userRepository.updateAddress(userId, addressId, newAddress);
    }

    public User saveUser(User user) {
        return userRepository.save(user);
    }

    public String deleteUserById(int id) {
        boolean result = userRepository.deleteById(id);
        return result ? "User deleted successfully" : "User not found";
    }

    public User updateUserAttribute(int userId, Map<String, Object> updates) {
        User user = userRepository.findById(userId);
        if (user != null) {
            updates.forEach((key, value) -> {
                if (value != null) {
                    userRepository.updateUserAttribute(userId, key, value.toString());
                } else {
                    userRepository.updateUserAttribute(userId, key, null);
                }
            });
            return userRepository.findById(userId);
        }
        return null;
    }

    public User getUserById(int id) {
        return userRepository.findById(id);
    }
}
